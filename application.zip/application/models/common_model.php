<?php
/**
 * 
 */
class Common_model extends CI_Model
{
	
	function __construct(){
		parent::__construct();
	}

	public function checkUserLogin($data){
		$this->db->select('*');
		$this->db->from('tbl_users');
		$this->db->where([ 'user_email'=>$data['user_email'], 'password'=>$data['password'], 'user_type'=>'admin'] );
		$query = $this->db->get();
		return $query->row();
	}

	public function addData($tbl='', $data = []){
		if($tbl != '' && !empty($data)){
			$this->db->insert($tbl, $data);
			return $this->db->insert_id();
		}else{
			return false;
		}
	}

	public function updateData($tbl='', $where_arr=[], $data=[]){
		if($tbl!='' && !empty($where_arr) && !empty($data)){
			$this->db->where($where_arr);
			$query = $this->db->update($tbl, $data);
			return $query;
		}
	}

	public function getData($tbl='', $fetch_type='result', $where_arr=[], $order_by='', $limit='', $offset=0, $last_query='No'){
		try{
			$this->db->select('*');
		
			$this->db->from($tbl);
			
			if(!empty($where_arr)){
				$this->db->where($where_arr);
			}

			if(!empty($order_by)){
				$this->db->order_by($order_by);
			}

			if(!empty($limit)){
				$this->db->limit($limit, $offset);	
			}

			$query = $this->db->get();

			if($last_query == 'Yes' ){
				echo $this->db->last_query();die;
			}

			if($fetch_type == 'result'){
				return $query->result();
			}elseif($fetch_type == 'result_array'){
				return $query->result_array();
			}elseif($fetch_type == 'row'){
				return $query->row();
			}elseif($fetch_type == 'row_array'){
				return $query->row_array();
			}else{
				return $query->result();
			}
		}catch(Exception $e){
			return 	"Error : ". $e->getMessage();
		}
	}

	public function getCustomQueryData($sql='', $data=[]){
		$this->db->query($sql, $data);

	}

	public function createSearchUserTable($user_id){
		$sql = "CREATE TABLE `wardrobe_wizard`.`tbl_search_user_".$user_id."` ( `search_id` INT(11) NOT NULL AUTO_INCREMENT, `search_query` VARCHAR(255) NOT NULL DEFAULT '' , `search_category` VARCHAR(255) NOT NULL DEFAULT '' , `search_limit` INT(11) NOT NULL DEFAULT '10' , `search_start` INT(11) NOT NULL DEFAULT '1' , `color_code` VARCHAR(255) NOT NULL DEFAULT '' , `nearest_color_name` VARCHAR(255) NOT NULL DEFAULT '' , `search_date` DATE NULL DEFAULT NULL, `created_at` DATETIME NULL DEFAULT NULL , `updated_at` DATETIME NOT NULL , PRIMARY KEY (`search_id`)) ENGINE = InnoDB;";
		return $this->db->query($sql);
	}

	public function getTotalSearchedByUser(){
		$this->db->select('SUM(total_search) as total_search');
		$this->db->from('tbl_search_count');
		$this->db->where(['search_date'=>date('Y-m-d')]);
		$query = $this->db->get();
		return $query->row();
	}

	public function addOrUpdateSearchCountByDate($data){
		$this->db->where('search_date',date('Y-m-d'));
	  	$q = $this->db->get('tbl_search_count');
	  	$row = $q->row();
	   	if ( $q->num_rows() > 0 ) 
	   	{
	   		$total_search = $row->total_search + $data['total_search'];
	     	$this->db->where('search_date',date('Y-m-d'));
	      	$this->db->update('tbl_search_count', ['total_search'=>$total_search]);
	   	} else {
	      	// $this->db->set('user_id', $id);
	      	$this->db->insert('tbl_search_count',$data);
	   	}
	}
}
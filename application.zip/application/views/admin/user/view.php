<div class="content-wrapper" style="min-height: 1015.13px;">
    <!-- Content Header (Page header) -->
	<section class="content-header">
	  <div class="container-fluid">
	    <div class="row mb-2">
	      <div class="col-sm-6">
	        <h1><?php echo $header_name ?></h1>
	      </div>
	      <div class="col-sm-6">
	        <ol class="breadcrumb float-sm-right">
	          <li class="breadcrumb-item"><a href="<?= base_url().'dasboardController'; ?>">Dashboard</a></li>
	          <li class="breadcrumb-item"><a href="<?= base_url().'userController'; ?>">Users</a></li>
	          <li class="breadcrumb-item active"><?php echo $header_name ?></li>
	        </ol>
	      </div>
	    </div>
	  </div><!-- /.container-fluid -->
	</section>

	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<!-- general form elements -->
					<div class="card card-primary">
						<div class="card-header">
							<h3 class="card-title"><?php echo $header_name ?></h3>
						</div>
						<!-- /.card-header -->
						<!-- form start -->
						<form role="form">
							<div class="card-body">
								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="user_name">User Name</label>
											<input disabled type="text" class="form-control" id="user_name" placeholder="Enter email" value="<?php echo ($user->user_name) ? $user->user_name : ''; ?>">
										</div>
										<div class="form-group">
											<label for="user_email">Email</label>
											<input disabled type="text" class="form-control" id="user_email" value="<?php echo ($user->user_email) ? $user->user_email : ''; ?>">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="user_mobile">Mobile</label>
											<input disabled type="text" class="form-control" id="user_mobile" value="<?php echo ($user->user_mobile) ? $user->user_mobile : ''; ?>">
										</div>
										<div class="form-group">
											<label for="gender">Gender</label>
											<input disabled type="text" class="form-control" id="gender" value="<?php echo ($user->gender) ? $user->gender : ''; ?>">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-md-6">
										 <div class="form-group">
											<label for="user_status">Status</label>
											<input disabled type="text" class="form-control" id="user_status" value="<?php echo ($user->user_status == 1) ? 'Active' : 'Inactive'; ?>">
										</div>
									</div>
								</div>
							</div>
							<!-- /.card-body -->

							<div class="card-footer">
								<a class="btn btn-primary" href="<?= base_url().'userController'; ?>" >Back</a>
							</div>
						</form>
					</div>
					<!-- /.card -->

				</div>
				
			</div>
		</div>
	</section>
</div>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo isset($header_name) ? $header_name : '' ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url().'dashboardController' ?>">Dashboard</a></li>
              <li class="breadcrumb-item active"><?php echo isset($header_name) ? $header_name : '' ?></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>
	
	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-header">
						<h3 class="card-title">DataTable with minimal features & hover style</h3>
					</div>
					<!-- /.card-header -->
					<div class="card-body">
						<table id="example2" class="table table-bordered table-hover">
							<thead>
								<tr>
									<th>Sr.No.</th>
									<th>User Name</th>
									<th>Email</th>
									<th>Mobile</th>
									<th>Gender</th>
									<th>Status</th>
									<th>Created</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach($users as $user){
									?>
										<tr>
											<td><?php echo $user->id; ?></td>
											<td><?php echo $user->user_name; ?></td>
											<td><?php echo $user->user_email; ?></td>
											<td><?php echo $user->user_mobile; ?></td>
											<td><?php echo $user->gender; ?></td>
											<!-- <td><?php echo $user->user_status; ?></td> -->
											<td>
												<select id="user_status">
													<option <?php echo ($user->user_status == '1') ? 'selected' : ''; ?>>Active</option>
													<option <?php echo ($user->user_status == '0') ? 'selected' : ''; ?>>Inactive</option>
												</select>
											</td>
											<td><?php echo $user->created_at; ?></td>
											<td>
												<a class="btn btn-info btn-xs" href="<?php echo base_url().'userController/view/'.$user->id ?>"><i class="fa fa-eye"></i></a>
												<a class="btn btn-success btn-xs" href="<?php echo base_url().'userController/register/'.$user->id ?>"><i class="fa fa-edit"></i></a>
												<a class="btn btn-danger btn-xs" href="javascript:;"><i class="fa fa-trash"></i></a>
											</td>
										</tr>
									<?php
								} ?>
							</tbody>
						</table>
					</div>
					<!-- /.card-body -->
				</div>
				<!-- /.card -->
			</div>
		</div>
	</section>
</div>


<!-- DataTables -->
<script src="<?php echo base_url(); ?>assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Wardrobe Wizard | Registration</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Font Awesome -->
	<link rel="stylesheet" href=<?php echo base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
	<!-- Ionicons -->
	<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<!-- icheck bootstrap -->
	<link rel="stylesheet" href=<?php echo base_url(); ?>assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
	<!-- Theme style -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/adminlte/css/adminlte.min.css">
	<!-- Google Font: Source Sans Pro -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
	<style type="text/css">
		.invalid-feedback{
			display: block;
		}
	</style>
</head>
<body class="hold-transition register-page">
	<div class="register-box">
		<div class="register-logo">
			<a href="<?php echo base_url(); ?>"><b>wardrobe</b>Wizard</a>
		</div>

		<div class="card">
			<div class="card-body register-card-body">
				<p class="login-box-msg">Register a new user</p>

				<form action="<?php echo base_url().'userController/register' ?>" method="post" id="userRegisterForm">
					<?php
						$csrf = array(
					    'name' => $this->security->get_csrf_token_name(),
					    'hash' => $this->security->get_csrf_hash()
					    );
					?>
					<input type="hidden" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" />
					<div class="input-group mb-3">
						<input type="text" id="user_name" name="user_name" class="form-control" placeholder="User name" value="<?php echo set_value('user_name'); ?>">
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-user"></span>
							</div>
						</div>
						<span id="user_name-error" class="error invalid-feedback"><?php echo form_error('user_name'); ?></span>
					</div>
					<div class="input-group mb-3">
						<input type="email" id="user_email" name="user_email" class="form-control" placeholder="Email" value="<?php echo set_value('user_email') ?>">
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-envelope"></span>
							</div>
						</div>
						<span id="user_email-error" class="error invalid-feedback"><?php echo form_error('user_email'); ?></span>
					</div>
					<div class="input-group mb-3">
						<input type="number" id="user_mobile" name="user_mobile" class="form-control" placeholder="Mobile" value="<?php echo set_value('user_mobile') ?>">
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-mobile"></span>
							</div>
						</div>
						<span id="user_mobile-error" class="error invalid-feedback"><?php echo form_error('user_mobile'); ?></span>
					</div>
					<div class="input-group mb-3">
						<input type="password" id="password" name="password" class="form-control" placeholder="Password">
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-lock"></span>
							</div>
						</div>
						<span id="password-error" class="error invalid-feedback"><?php echo form_error('password'); ?></span>
					</div>
					<div class="input-group mb-3">
						<input type="password" id="c_password" name="c_password" class="form-control" placeholder="Retype password">
						<div class="input-group-append">
							<div class="input-group-text">
								<span class="fas fa-lock"></span>
							</div>
						</div>
						<span id="c_password-error" class="error invalid-feedback"><?php echo form_error('c_password'); ?></span>
					</div>
					<div class="input-group clearfix">
						<div class="icheck-primary d-inline">
							<input type="radio" id="male" name="gender" value="male" checked>
							<label for="male">
								Male
							</label>
						</div>
						&nbsp;&nbsp;&nbsp;
						<div class="icheck-primary d-inline">
							<input type="radio" id="female" name="gender" value="female">
							<label for="female">
								Female
							</label>
						</div>
					</div>
					<div class="row">
						<!-- /.col -->
						<div class="col-4">
							<button type="submit" id="register" name="register" value="save" class="btn btn-primary btn-block btn-flat">Register</button>
						</div>
						<!-- /.col -->
					</div>
				</form>

				<a href="<?php echo base_url(); ?>userController/login" class="text-center">I already have a membership</a>
			</div>
			<!-- /.form-box -->
		</div><!-- /.card -->
	</div>
	<!-- /.register-box -->

	<!-- jQuery -->
	<script src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
	<!-- Bootstrap 4 -->
	<script src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script type="text/javascript">
	/*$(document).ready(function(){
		$(document).on('click', '#register', function(){
			var password = $('#password').val();
			var c_password = $('#c_password').val();
			$('#password').val(SHA256(password));
			$('#c_password').val(SHA256(c_password));
		});
	})*/
</script>
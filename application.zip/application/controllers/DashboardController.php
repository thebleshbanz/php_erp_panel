<?php
/**
 * 
 */
class DashboardController extends MY_Controller
{

	function __construct(){
		parent::__construct();
	}

	public function index(){
		$data['controllerName'] = $this->uri->segment(1);
		$data['header_name'] = 'Dashboard';
		$this->adminView('admin/dashboard', $data);
	}
}
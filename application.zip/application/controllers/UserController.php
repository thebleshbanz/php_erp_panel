<?php
/**
 * 
 */
class UserController extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

	public function login(){
		if(empty($this->session_val['user'])){

			$login_rules = [
				[
					'field'		=>	'user_email',
					'label'		=>	'User Email',
					'rules'		=>	'required'
				],
				[
					'field'		=>	'password',
					'label'		=>	'Password',
					'rules'		=>	'required'
				]
			];

		if( !empty($_POST) && isset($_POST['submit']) &&  $_POST['submit'] == 'login' ){
			$this->form_validation->set_rules($login_rules);
			if($this->form_validation->run()){
				$form_data = [];
				$data = $this->input->post();
				$form_data['user_email'] = $data['user_email'];
				$form_data['password'] 	= md5($data['password']);
				$res = $this->checkUserLogin($form_data);
				if($res){
					$this->session->set_flashdata(['status'=>'success', 'message'=>'You are login successfully!']);
					redirect(base_url().'dashboardController');
				}else{
					$this->session->set_flashdata(['status'=>'fail', 'message'=>'email and password Not matched. please try again!']);
					redirect(base_url().'userController/login');
				}
			}else{
				$this->load->view('login');
			}
		}else{
			$this->load->view('login');
		}
		}else{
			redirect(base_url().'dashboardController');
		}
	}

	public function register(){
		if(empty($this->session_val['user'])){

			$user_rules = [
				'add' => [
					[
						'field' => 'user_name',
						'label' => 'User Name',
						'rules' => 'required',
					],
					[
						'field' => 'user_email',
						'label' => 'User Email',
						'rules' => 'required|valid_email|is_unique[tbl_users.user_email] ',
					],
					[
						'field' => 'user_mobile',
						'label' => 'User Mobile',
						'rules' => 'required|numeric|is_unique[tbl_users.user_mobile]|min_length[10]|max_length[11] ',
					],
					[
						'field' => 'password',
						'label' => 'Password',
						'rules' => 'required|min_length[6]',
					],
					[
						'field' => 'c_password',
						'label' => 'Confirm Password',
						'rules' => 'required|matches[password] ',
					],
				]
			];

			$user_id = $this->uri->segment(3);
			if( !empty($user_id) && is_numeric($user_id)){

			}else{
				if( !empty($_POST) && isset($_POST['register']) &&  $_POST['register'] == 'save' ){
					$this->form_validation->set_rules($user_rules['add']);
					if($this->form_validation->run()){
						$form_data = [];
						$data = $this->input->post();
						$token_key = bin2hex($this->encryption->create_key(16));
						$user_otp  = mt_rand(100000, 999999);
						$form_data['user_name'] 	= $data['user_name'];
						$form_data['user_email'] 	= $data['user_email'];
						$form_data['user_mobile'] 	= $data['user_mobile'];
						$form_data['password'] 		= md5($data['password']);
						$form_data['gender'] 		= $data['gender'];
						$form_data['token_key']		= $token_key;
						$form_data['user_otp']		= $user_otp;
						$form_data['user_status'] 	= '1';
						$form_data['user_type'] 	= 'user';
						$form_data['created_at'] 	= date('Y-m-d H:i:s');
						$form_data['updated_at'] 	= date('Y-m-d H:i:s');

						$user_id = $this->common_model->addData('tbl_users', $form_data);

						if($user_id){

							if($this->common_model->createSearchUserTable($user_id)){

								$search_tbl_data = [
									'user_id'=>$user_id, 
									'model_type'=>'search', 
									'table_name'=>'tbl_search_user_'.$user_id,
									'created_at'=>date('Y-m-d H:i:s'), 
									'updated_at'=>date('Y-m-d H:i:s'), 
								];
								$this->common_model->addData('tbl_user_search_tables', $search_tbl_data);
							}
							$subject = "Wardrobe Wizard - Verify Account";
							$mail_data = ['user_name'=>$data['user_name'], 'user_mail'=>$data['user_mail'], 'user_otp'=>$user_otp];
							$message = $this->load->view('mail/verify_mail', $mail_data, true);
							$res = $this->send_mail($data['user_email'], $subject, $message);

							$this->session->set_flashdata(['status'=>'success', 'message'=>'User has been register successfully!']);
							redirect(base_url().'userController/userVerify/'.$user_id);
						}
					}else{
						$this->load->view('register');
					}
				}else{
					$this->load->view('register');
				}
			}
		}else{
			redirect(base_url().'dashboardController');			
		}
	}

	public function index(){
		if(!empty($this->session_val['user'])){
			$data['controllerName'] = $this->uri->segment(1);
			$data['header_name'] = 'Users';
			$data['users'] = $this->common_model->getData('tbl_users', 'result', ['user_status != '=>'2'], 'id DESC', '', '', 'No');
			$this->adminView('admin/user/index', $data);
		}else{
			redirect(base_url().'userController/login');
		}
	}

	public function view($id=''){
		$user_id = $this->uri->segment(3);
		if( !empty($user_id) && is_numeric($user_id)){
			$data['controllerName'] = $this->uri->segment(1);
			$data['header_name'] = 'Users View';
			$data['user'] = $this->common_model->getData('tbl_users', 'row', ['id'=>$user_id, 'user_status != '=>'2'] );
			$this->adminView('admin/user/view', $data);
		}else{
			redirect(base_url().'dashboardController');
		}
	}

	public function userVerify(){
		$user_id = $this->uri->segment(3);
		if( !empty($user_id) && is_numeric($user_id))
		{
			$user_res = $this->common_model->getData('tbl_users', 'row', ['id'=>$user_id]);

			if(!empty($user_res)){
				$user_id = $user_res->id;
				$user_otp = $user_res->user_otp;
				if($user_res->is_verify == 0)
				{
					$verify_rules = [
						[
							'field'		=>	'user_otp',
							'label'		=>	'User OTP',
							'rules'		=>	'required|numeric'
						]
					];
					if( !empty($_POST) && isset($_POST['submit']) &&  $_POST['submit'] == 'verify' ){
						$this->form_validation->set_rules($verify_rules);
						if($this->form_validation->run()){
							$otp_post = $this->input->post('user_otp');
							if($user_otp === $otp_post){
								$this->common_model->updateData('tbl_users', ['id'=>$user_id], ['user_otp'=>'','is_verify'=>'1']);
								echo "Verify user successfully";
							}else{
								$this->session->set_flashdata(['status'=>'fail', 'message'=>'Wrong OTP please try again!']);
								redirect(base_url().'userController/userVerify/'.$user_id);
							}
						}else{
							$data = ['user_id'=>$user_id];
							$this->load->view('verify_form', $data);
						}
					}else{
						$data = ['user_id'=>$user_id];
						$this->load->view('verify_form', $data);
					}
				}else{
					echo "User already verified.";
				}
			}else{
				redirect(base_url());
			}
		}else{
			redirect(base_url().'userController/login');
		}
	}
}
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ColorConvertion
{
    public function __construct($para=[]){
        require_once APPPATH.'third_party/ColorConvertion/color_map.php';
        $color = '';
		$rgb = [];
		$hsl = [];
		
		for($i = 0; $i < count($names); $i++){
			$color = "#".$names[$i][0];
			$rgb = $this->rgb($color);
			$hsl = $this->hsl($color);
			array_push($names[$i], $rgb[0], $rgb[1], $rgb[2], $hsl[0], $hsl[1], $hsl[2] );
		}
        $this->names = $names;
    }

    public function init(){
    	$names = $this->names;
		$color = '';
		$rgb = [];
		$hsl = [];
		
		for($i = 0; $i < count($names); $i++)
		{
			$color = "#".$names[$i][0];
			$rgb = $this->rgb($color);
			$hsl = $this->hsl($color);
			array_push($names[$i], $rgb[0], $rgb[1], $rgb[2], $hsl[0], $hsl[1], $hsl[2] );
		}
	}

	function name($color){
		$names = $this->names;
		$color = strtoupper($color);

		if(strlen($color) < 3 || strlen($color) > 7)
			return ["#000000", "Invalid Color: ".$color, false];
		
		if(strlen($color) % 3 == 0)
			$color = "#".$color;

		$rgb = $this->rgb($color);
		$r 	 = $rgb[0]; $g = $rgb[1]; $b = $rgb[2];
		$hsl = $this->hsl($color);
		$h 	 = $hsl[0]; $s = $hsl[1]; $l = $hsl[2];
		$ndf1 	= 0; $ndf2 = 0; $ndf = 0;
		$cl		= -1; $df = -1;

		for($i = 0; $i < count($names); $i++)
		{
			if($color == "#".$names[$i][0])
				return ["#".$names[$i][0], $names[$i][1], true];

			$ndf1 = pow($r - $names[$i][2], 2) + pow($g - $names[$i][3], 2) + pow($b - $names[$i][4], 2);
			$ndf2 = pow($h - $names[$i][5], 2) + pow($s - $names[$i][6], 2) + pow($l - $names[$i][7], 2);
			$ndf = $ndf1 + $ndf2 * 2;
			if($df < 0 || $df > $ndf)
			{
				$df = $ndf;
				$cl = $i;
			}
		}
		return ($cl < 0 ? ["#000000", "Invalid Color: ".$color, false] : ["#".$names[$cl][0], $names[$cl][1], false]);
	}


	private function rgb($color) {
		return [hexdec("0x".substr($color, 1, 2)), hexdec("0x".substr($color, 3, 2)), hexdec("0x".substr($color, 5, 2))];
	}

	private function hsl($color) {

		$rgb = [hexdec('0x'.substr($color, 1, 2)) / 255, hexdec('0x'.substr($color, 3, 2)) / 255, hexdec('0x'.substr($color, 5, 2)) / 255];
		$min = $max = $delta = $h = $s = $l = 0;
		$r = $rgb[0]; $g = $rgb[1]; $b = $rgb[2];
		
		$min = min($r, min($g, $b));
		$max = max($r, max($g, $b));
		$delta = $max - $min;
		$l = ($min + $max) / 2;

		$s = 0;
		if($l > 0 && $l < 1)
			$s = $delta / ($l < 0.5 ? (2 * $l) : (2 - 2 * $l));
		
		$h = 0;
		if($delta > 0)
		{
			if ($max == $r && $max != $g) $h += ($g - $b) / $delta;
			if ($max == $g && $max != $b) $h += (2 + ($b - $r) / $delta);
			if ($max == $b && $max != $r) $h += (4 + ($r - $g) / $delta);
			$h /= 6;
		}
		
		return [intval($h * 255), intval($s * 255), intval($l * 255)];

	}
}
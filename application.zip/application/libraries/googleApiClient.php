<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class GoogleApiClient
{
    public function __construct()
    {
        require_once APPPATH.'third_party/google-api-php-client/vendor/autoload.php';
    }
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Myclass {

        public function my_method()
        {
        	echo "my_method";
        }
}
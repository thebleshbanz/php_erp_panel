<?php
/**
 * 
 */
class MY_Controller extends CI_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
		$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
		$this->output->set_header('Pragma: no-cache');
		
		$this->is_logedin = false; // set login status false
		$this->session_val['user'] = $this->getSessionData();
	}
	/* get user data in array and check user credentials */
	public function checkUserLogin($data = []){
		if(!empty($data)){
			$res = $this->common_model->checkUserLogin($data);
			if(!empty($res)){
				$this->session->set_userData('user', $res);
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function getSessionData(){
		if($this->session->has_userdata('user') ){
			return $this->session->userData('user');
		}else{
			return array();
		}
	}

	public function adminView($view_page, $data){
		$sess_val = $this->getSessionData();
		if(!empty($sess_val)){
			$dat['myobj'] = $this;
			$this->load->view('admin/layout/header', $data);
			$this->load->view('admin/layout/sidebar', $data);
			$this->load->view($view_page, $data);
			$this->load->view('admin/layout/footer', $data);
		}else{
			redirect(base_url());
		}
	}

	/* XSS Clean */
	function xssCleanValidate($input_array)
	{
		$out_array = array();
		foreach ($input_array as $key => $value) 
		{
			$out_array[$key] = $this->security->xss_clean($value); 
		}
		return $out_array;
	}

	/* Mail Send */
	public function send_mail($email, $subject, $message)	
	{
		$this->load->library('PHPMailer/phpmailer');
		$mail = new PHPMailer();
		$mail->IsSMTP();   
		$mail->Host = "smtp.gmail.com";  // specify main and backup server
		$mail->SMTPAuth = true;     // turn on SMTP authentication
		$mail->Username = "ashish.thinkdebug@gmail.com";  // SMTP username
		$mail->Password = "#AB@thinkdebug"; // SMTP password
		$mail->SMTPSecure = "tls";
		$mail->Port = 587;
		$mail->From = "info@thinkdebug";
		$mail->FromName = "Wardrobe Wizard";
		$mail->AddAddress($email);
		$mail->WordWrap = 50; 
		$mail->IsHTML(true); 
		$mail->Subject = $subject;
		$mail->Body    = $message;
		if(!$mail->Send()){
		  return false;
		}else{
			return true;
		}
	}

	/* test image upload */
	public function do_upload()
    {
        $config['upload_path']          = './assets/upload/products';
        $config['allowed_types']        = 'gif|jpg|png';
        // $config['max_size']             = 100;
        // $config['max_width']            = 1024;
        // $config['max_height']           = 768;
        $this->load->library('upload', $config);
		$this->upload->initialize($config);

        if ( ! $this->upload->do_upload('prodct_img')){
            $error = array('error' => $this->upload->display_errors());
            echo json_encode($error);
        }else{
            $data = array('upload_data' => $this->upload->data());
            echo json_encode($data);
        }
    }

    /* Upload Image */
	public function ImageUpload($filename, $name, $imagePath, $fieldName)
	{
		$temp = explode(".",$filename);
		$extension = end($temp);
		$filenew =  date('d-M-Y').'_'.str_replace($filename,$name,$filename).'_'.time().''.rand(). "." .$extension;
		$config['file_name'] = $filenew;
		$config['upload_path'] = $imagePath;
		$config['allowed_types'] = 'GIF|gif|JPE|jpe|JPEG|jpeg|JPG|jpg|PNG|png';
		$this->upload->initialize($config);
		// $this->upload->set_allowed_types('*');
		$this->upload->set_filename($config['upload_path'], $filenew);

		if(!$this->upload->do_upload($fieldName)){
			$data = array('error' => $this->upload->display_errors());
			return $data;
		}else{ 
			$data = $this->upload->data();
			$imageName = $data['file_name'];	
			return $data;
		}	
	}

	/* Upload Image */
	public function FileUpload($filename, $name, $imagePath, $fieldName, $allowed_types)
	{
		$temp = explode(".",$filename);
		$extension = end($temp);
		$filenew =  date('d-M-Y').'_'.str_replace($filename,$name,$filename).'_'.time().''.rand(). "." .$extension;  	
		$config['file_name'] = $filenew;
		$config['upload_path'] = $imagePath;
		$config['allowed_types'] = $allowed_types;
		$this->upload->initialize($config);
		$this->upload->set_allowed_types('*');
		$this->upload->set_filename($config['upload_path'],$filenew);

		if(!$this->upload->do_upload($fieldName))
		{
			$data = array('msg' => $this->upload->display_errors());
		}
		else 
		{ 
			$data = $this->upload->data();
			$imageName = $data['file_name'];	
			return $imageName;
		}	
	}
}